scp -rv shofer@login.nird.sigma2.no:/projects/NS9600K/shofer/blowing_snow/*.png .
